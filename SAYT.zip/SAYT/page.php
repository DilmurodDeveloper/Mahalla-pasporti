<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Mahalla Pasporti</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Mahalla pasporti" name="keywords">
   

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&family=Rubik:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner"></div>
    </div>
    <!-- Spinner End -->

    <!-- Topbar Start -->
    <div class="container-fluid bg-dark px-5 d-none d-lg-block">
        <div class="row gx-0">
            <div class="col-lg-8 text-center text-lg-start mb-2 mb-lg-0">
                <div class="d-inline-flex align-items-center" style="height: 45px;">
                    <small class="me-3 text-light"><i class="bi bi-geo-alt text-primary me-2"></i>Yangiariq tumani Ogahiy mahallasi</small>
                    <small class="me-3 text-light"><i class="bi bi-clock text-primary me-2"></i> Dushshanba - Shanba : 08:30 dan - 17:30 gacha</small>
                </div>
            </div>
            <div class="col-lg-4 text-center text-lg-end">
                <div class="d-inline-flex align-items-center" style="height: 45px;">
                    <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href="https://twitter.com"><i class="fab fa-twitter fw-normal"></i></a>
                    <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href="https://facebook.com"><i class="fab fa-facebook-f fw-normal"></i></a>
                    <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href="https://linkedin.com"><i class="fab fa-linkedin-in fw-normal"></i></a>
                    <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href="https://instagram.com"><i class="fab fa-instagram fw-normal"></i></a>
                    <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle" href="https://youtube.com"><i class="fab fa-youtube fw-normal"></i></a>
                </div>
            </div>
        </div>
    </div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
    <div class="container-fluid position-relative p-0">
        <nav class="navbar navbar-expand-lg navbar-dark px-5 py-3 py-lg-0">
            <a href="index.php" class="navbar-brand p-0">
                <h1 class="m-0"><i class="fa fa-users me-2"></i>Ogahiy MFY</h1>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="fa fa-bars"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav ms-auto py-0">
                    <a href="index.php" class="nav-item nav-link">Bosh sahifa</a>               
                    <div class="nav-item dropdown">
                        <a href="page.php" class="nav-link nav-link active">Mahalla pasporti</a>
                    </div>
                    <a href="contact.php" class="nav-item nav-link">Contact</a>
                </div>
            </div>
        </nav>

        <div class="container-fluid bg-primary py-5 bg-header" style="margin-bottom: 90px;">
            <div class="row py-5">
                <div class="col-12 pt-lg-5 mt-lg-5 text-center">
                    <h1 class="display-4 text-white animated zoomIn">Ogahiy  mahalla fuqarolar yig'inining pasporti</h1>
                </div>
            </div>
        </div>
    </div>
    <!-- Navbar End -->

    <!--Pages start-->
    <div class="container"> 
        <div class="row">
            <span class="ml1 col">
                <span class="text-wrapper">
                  <h3 class="letters">Mahalla pasporti yig'ma jadvalini ko'rish uchun tugmani bosing!!!</h3>
                </span>
            </span>
              <button type="button" class="bi bi-box-arrow-in-right btn btn-danger col-4"><a class="text-light text-uppercase" href="admin.php"> Mahalla pasporti yig'ma jadvali</a></button>
              <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
              <style>
              .ml1 {
                font-weight: 900;
                font-size: 3.5em;
              }
              
              .ml1 .letter {
                display: inline-block;
                line-height: 1em;
              }
              
              .ml1 .text-wrapper {
                position: relative;
                display: inline-block;
                padding-top: 0.1em;
                padding-right: 0.05em;
                padding-bottom: 0.15em;
              }
              
              .ml1 .line {
                opacity: 0;
                position: absolute;
                left: 0;
                height: 3px;
                width: 100%;
                background-color: #fff;
                transform-origin: 0 0;
              }
              .ml1 .line1 { top: 0; }
              .ml1 .line2 { bottom: 0; }
              </style>
              
              <script>// Wrap every letter in a span
                var textWrapper = document.querySelector('.ml1 .letters');
                textWrapper.innerHTML = textWrapper.textContent.replace(/\S/g, "<span class='letter'>$&</span>");
                
                anime.timeline({loop: true})
                  .add({
                    targets: '.ml1 .letter',
                    scale: [0.3,1],
                    opacity: [0,1],
                    translateZ: 0,
                    easing: "easeOutExpo",
                    duration: 600,
                    delay: (el, i) => 70 * (i+1)
                  }).add({
                    targets: '.ml1 .line',
                    scaleX: [0,1],
                    opacity: [0.5,1],
                    easing: "easeOutExpo",
                    duration: 700,
                    offset: '-=875',
                    delay: (el, i, l) => 80 * (l - i)
                  }).add({
                    targets: '.ml1',
                    opacity: 0,
                    duration: 1000,
                    easing: "easeOutExpo",
                    delay: 1000
                  });
                  </script>
              </div>
        <style>a.button {
            border: 1px solid #808080;
            background: #a0a0a0;
            display: inline-block;
            padding: 5px;
            text-transform: capitalize;
        }</style>
    </div>
    <!--pages end-->


    <!-- About Start -->
    <div class="container-fluid py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-lg-7">
                    <div class="section-title position-relative pb-3 mb-5">
                        <h5 class="fw-bold text-primary text-uppercase">Ma'lumot</h5>
                        <h1 class="mb-0">Ogahiy mahallasi</h1>
                    </div>
                    <div class="row g-0 mb-3">
                        <div class="col-md-12" data-wow-delay="0.2s">
                            <h5 class="mb-2"><i class="fa fa-check text-primary"></i> Tashkil topgan sanasi: <b>25.05.2012</b></h5>
                            <h5 class="mb-2"><i class="fa fa-check text-primary"></i> Umumiy yer maydoni: <b>82.9 ga</b></h5>
                            <h5 class="mb-2"><i class="fa fa-check text-primary"></i> Tarkibidagi aholi punktlari: <b>q.a.p Ogahiy</b></h5>
                            <h5 class="mb-2"><i class="fa fa-check text-primary"></i> Tarkibidagi ko'chalar soni: <b>12 ta</b></h5>
                            <h5 class="mb-2"><i class="fa fa-check text-primary"></i> Tarkibidagi ko'p qavatli uylar soni: <b>1 ta</b></h5>
                            <h5 class="mb-2"><i class="fa fa-check text-primary"></i> Tarkibidagi yakka tartibdagi hovlilar soni: <b>423 ta</b></h5>
                            <h5 class="mb-2"><i class="fa fa-check text-primary"></i> Tarkibidagi aholi doimiy yashamaydigan xonadonlar (kvartiralar) soni: <b>1 ta</b></h5>
                            <h5 class="mb-2"><i class="fa fa-check text-primary"></i> Qo'shni davlatlar bilan chegaradoshligi: <b>Yo'q</b></h5>
                        </div>
                    </div>
                    <div class="d-flex align-items-center mb-4 wow fadeIn" data-wow-delay="0.6s">
                        <div class="bg-primary d-flex align-items-center justify-content-center rounded" style="width: 60px; height: 60px;">
                            <i class="fa fa-phone-alt text-white"></i>
                        </div>
                        <div class="ps-4">
                            <h5 class="mb-2">Mahalla raisi: <b>Bekchanova Shaxnoza Baxodirovna</b></h5>
                            <h4 class="text-primary mb-0">+998 99 121 71 71</h4>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5" style="min-height: 500px;">
                    <div class="position-relative h-100">
                        <img class="position-absolute w-100 h-100 rounded wow zoomIn" data-wow-delay="0.9s" src="img/about.jpg" style="object-fit: cover;">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->

    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-light mt-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container">
            <div class="row gx-5">
                <div class="col-lg-8 col-md-6">
                    <div class="row gx-5">
                        <div class="col-lg-4 col-md-12 pt-5 mb-5">
                            <div class="section-title section-title-sm position-relative pb-3 mb-4">
                                <h3 class="text-light mb-0">Bog'lanish</h3>
                            </div>
                            <div class="d-flex mb-2">
                                <i class="bi bi-geo-alt text-primary me-2"></i>
                                <p class="mb-0">Yangiariq tumani, Ogahiy MFY</p>
                            </div>
                            <div class="d-flex mb-2">
                                <i class="bi bi-envelope-open text-primary me-2"></i>
                                <p class="mb-0">ogahiymfy@gmail.com</p>
                            </div>
                            <div class="d-flex mb-2">
                                <i class="bi bi-telephone text-primary me-2"></i>
                                <p class="mb-0">+998 99 111 22 33</p>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-12 pt-0 pt-lg-5 mb-5">
                            <div class="section-title section-title-sm position-relative pb-3 mb-4">
                                <h3 class="text-light mb-0">Tez havolalar</h3>
                            </div>
                            <div class="link-animated d-flex flex-column justify-content-start">
                                <a class="text-light mb-2" href="index.php"><i class="bi bi-arrow-right text-primary me-2"></i>Bosh sahifa</a>
                                <a class="text-light" href="contact.php"><i class="bi bi-arrow-right text-primary me-2"></i>Biz bilan bog'lanish</a>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-12 pt-0 pt-lg-5 mb-5">
                            <div class="section-title section-title-sm position-relative pb-3 mb-4">
                                <h3 class="text-light mb-0">Ommabop havolalar</h3>
                            </div>
                            <div class="link-animated d-flex flex-column justify-content-start">
                                <a class="text-light mb-2" href="index.php"><i class="bi bi-arrow-right text-primary me-2"></i>Bosh sahifa</a>
                                <a class="text-light" href="contact.php"><i class="bi bi-arrow-right text-primary me-2"></i>Biz bilan bog'lanish</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->
    


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square rounded back-to-top"><i class="bi bi-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>