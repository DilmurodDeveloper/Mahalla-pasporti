-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Янв 18 2023 г., 18:45
-- Версия сервера: 10.4.24-MariaDB
-- Версия PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `data`
--

-- --------------------------------------------------------

--
-- Структура таблицы `aholining_bandligi`
--

CREATE TABLE `aholining_bandligi` (
  `id` int(11) UNSIGNED NOT NULL,
  `korsatkichlar` varchar(100) NOT NULL,
  `kishi` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `aholining_bandligi`
--

INSERT INTO `aholining_bandligi` (`id`, `korsatkichlar`, `kishi`) VALUES
(1, 'Korxona va tashkilotlarda ishlovchilar soni', '463 nafar'),
(2, 'Tadbirkorlik bilan band bo\'lganlar', '272 nafar'),
(3, 'kasanachilik bilan band bo\'lganlar soni', 'Yo\'q'),
(4, 'milliy hunarmandchilik bilan shug\'ullanuvchilar soni', 'Yo\'q'),
(5, 'chorvachilik, parrandachilik va asalarichilik bilan band bo\'lganlar soni', '389 nafar'),
(6, 'tadbirkorlikning boshqa soxalarida band bo\'lganlar soni', '83 nafar'),
(7, 'Uzoq muddat xorijiy davlatlarga ish izlab ketganlar soni', '289 nafar'),
(8, 'Ishlovchi mehnatga layoqatli yoshdan kichik (bolalar)lar soni', 'Yo\'q'),
(9, 'Doimiy ish bilan band bo\'lganlar soni', '735 nafar'),
(10, 'Bola parvarishi bilan band bo\'lganlar soni', '81 nafar'),
(11, 'Talabalar soni', '34 nafar'),
(12, 'Ishlovchi pensionerlar soni', '23 nafar'),
(13, 'Ishsizlar soni', '128 nafar'),
(14, 'kasb-hunar kollejlari bitiruvchilari soni', '8 nafar'),
(15, 'oliy ta\'lim muassasalari bitiruvchilari soni', '6 nafar');

-- --------------------------------------------------------

--
-- Структура таблицы `aholining_ijtimoiy_holati`
--

CREATE TABLE `aholining_ijtimoiy_holati` (
  `id` int(11) UNSIGNED NOT NULL,
  `korsatkichlar` varchar(100) NOT NULL,
  `kishi` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `aholining_ijtimoiy_holati`
--

INSERT INTO `aholining_ijtimoiy_holati` (`id`, `korsatkichlar`, `kishi`) VALUES
(1, 'Boquvchisini yo\'qotgan oilalar soni, birlik', '7 nafar'),
(2, 'Yolg\'iz onalar/otalar soni', 'Onalar: 5 nafar,\r\nOtalar: 2 nafar'),
(3, 'Yolg\'iz keksalar soni', '4 nafar'),
(4, 'Kam ta\'minlangan oilalar soni, birlik', '31 ta'),
(5, '2 yoshgacha nafaqa oluvchi oilalar soni, birlik', '32 nafar'),
(6, '14 yoshgacha nafaqa oluvchi oilalar soni, birlik', '36 nafar'),
(7, 'moddiy yordam oluvchilar soni, birlik', '10 nafar'),
(8, 'Ko\'p bolali oilalar soni, birlik', '2 ta'),
(9, 'Nogironligi bo\'lgan shaxslar soni', '75 nafar'),
(10, 'nogironlik nafaqasi oluvchilar soni', '75 nafar'),
(11, 'Ikkinchi jahon urushi davrida front va front ortida qatnashgan hamda ularga tenglashtirilgan fuqarol', '2 nafar'),
(12, 'Baynalminal jangchilar va Chernobl\' AES halokatini bartaraf etishda ishtirok etganlar soni', '3 nafar'),
(13, 'Ijarada yashovchi fuqarolar soni', '7 ta');

-- --------------------------------------------------------

--
-- Структура таблицы `data1`
--

CREATE TABLE `data1` (
  `id` int(11) UNSIGNED NOT NULL,
  `lavozimlar` varchar(100) NOT NULL,
  `F_I_SH` varchar(100) NOT NULL,
  `yashash_manzili` varchar(255) NOT NULL,
  `phone_number` int(13) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `data1`
--

INSERT INTO `data1` (`id`, `lavozimlar`, `F_I_SH`, `yashash_manzili`, `phone_number`) VALUES
(1, 'Fuqarolar yig\'ini raisi', 'Eshchanov Quranboy', 'Ogahiy mahallasi O.Ollaberganov ko\'chasi 10-uy', 975107848),
(2, 'Fuqarolar yig\'ini raisining huquq-tartibot masalalari bo\'yicha o\'rinbosari - profilaktika inspektori', 'Nurullaev Izzatbek Otamurod o\'g\'li', 'Jaloil mahallasi Muruvvat ko\'cha 31-uy', 991153558),
(3, 'Fuqarolar yig\'ini raisining oila, xotin-qizlar va ijtimoiy-ma\'naviy masalalar bo\'yicha o\'rinbosari', 'Matqurbonova Gavharjon Matmurodovna', 'Ogahiy mahallasi , Al-Xorazmiy ko\'chasi 42-uy', 975113154),
(4, 'Fuqarolar yig\'ini raisining obodonlashtirish, tomorqa va tadbirkorlik masalalari bo\'yicha o\'rinbosar', 'Jumaniyozova Malohat Jumanazarovna', 'Ogahiy mahallasi , Yangiariq ko\'chasi 8-uy', 975157850),
(5, 'Fuqarolar yig\'ini raisining yoshlar masalalari bo\'yicha maslahatchisi', 'Xajiev Mirzobek Nuraddin o\'g\'li', 'Ogahiy mahallasi, Al-Xorazmiy ko\'chasi 42-uy', 937579585),
(6, 'Fuqarolar yig\'ini raisining keksalar va faxriylar ishlari bo\'yicha maslahatchisi', 'Baxtiyorov Xudoyor Rupiyorovich', 'Ogahiy mahallasi Tinchlik ko\'chasi 7-uy', 947791805);

-- --------------------------------------------------------

--
-- Структура таблицы `data2`
--

CREATE TABLE `data2` (
  `id` int(11) UNSIGNED NOT NULL,
  `lavozimlar` varchar(100) NOT NULL,
  `F_I_SH` varchar(100) NOT NULL,
  `phone_number` int(13) UNSIGNED NOT NULL,
  `azolar_soni` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `data2`
--

INSERT INTO `data2` (`id`, `lavozimlar`, `F_I_SH`, `phone_number`, `azolar_soni`) VALUES
(1, 'Oilaviy qadriyatlarni mustahkamlash komissiyasi raisi', 'Eshchanov Quranboy', 975107848, '9 nafar'),
(2, 'Xotin-qizlar bilan ishlash bo\'yicha komissiyasi raisi', 'Matqurbonova Gavharjon Matmurodovna', 975113154, '9 nafar'),
(3, 'Ijtimoiy qo\'llab-quvvatlash va jamoatchilik nazorati bo\'yicha komissiya raisi', 'Jumaniyozova Malohat Jumanazarovna', 975157848, '9 nafar'),
(4, 'Ekologiya va atrof-muhitni muhofaza qilish, obodonlashtirish va ko\'kalamzorlashtirish bo\'yicha komis', 'Jumaniyozova Malohat Jumanazarovna', 975157848, '9 nafar'),
(5, '«Keksalar maslahati» guruhi rahbari', 'Eshchanov Quranboy', 975107848, '9 nafar'),
(6, '«Ota-onalar universiteti» jamoatchilik tuzilmasi rahbari', 'Matqurbonova Gavharjon Matmurodovna', 975113154, '9 nafar'),
(7, '«Fidokor yoshlar» jamoatchilik patrul\' guruhi rahbari', 'Baxtiyorov Olloyor Xudoyorovich', 995719027, '9 nafar'),
(8, 'Maslahat markazi rahbari', 'Qo\'chqarova Nilufar Odiljonovna', 990423024, '9 nafar');

-- --------------------------------------------------------

--
-- Структура таблицы `demografik_korsatkichlar`
--

CREATE TABLE `demografik_korsatkichlar` (
  `id` int(11) UNSIGNED NOT NULL,
  `korsatkichlar` varchar(100) NOT NULL,
  `jami` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `demografik_korsatkichlar`
--

INSERT INTO `demografik_korsatkichlar` (`id`, `korsatkichlar`, `jami`) VALUES
(1, 'Oilalar soni, birlik', 910),
(2, 'Xonadon soni, birlik', 591),
(3, 'Uy xo\'jaliklari soni, birlik', 609),
(4, 'Axoli soni', 3549),
(5, '0-30 yosh', 1764),
(6, '0-2 yosh', 75),
(7, '3-6 yosh', 178),
(8, '7-13 yosh', 399),
(9, '14-17 yosh', 349),
(10, '18-30 yosh', 633),
(11, 'Mehnatga layoqatli yoshdan yuqori aholi soni(55 yoshdan katta ayollar va 60 yoshdan katta erkaklar)', 200);

-- --------------------------------------------------------

--
-- Структура таблицы `qishloq_xojaligi`
--

CREATE TABLE `qishloq_xojaligi` (
  `id` int(11) UNSIGNED NOT NULL,
  `korsatkichlar` varchar(100) NOT NULL,
  `birlik` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `qishloq_xojaligi`
--

INSERT INTO `qishloq_xojaligi` (`id`, `korsatkichlar`, `birlik`) VALUES
(1, 'Tomorqasi bor hovlilar soni', '423 nafar'),
(2, 'Tomorqasi bor hovlilarning umumiy maydoni', '25.3 ga'),
(3, 'shundan ekin maydoni', '12.6 ga'),
(4, 'Tomorqasida issiqxona va parniklar bor oilalar soni', '25 nafar'),
(5, 'Tomorqadan unumli foydalanayotgan xonadonlar soni', '423 nafar'),
(6, 'Chorvachilik bilan shug\'ullanadigan xonadonlar soni', '225 ta'),
(7, 'yirik shoxli qoramollar', '286 bosh'),
(8, 'qo\'y va echkilar', '25 bosh'),
(9, 'Parrandachilik bilan shug\'ullanadigan xonadonlar soni', '351 ta'),
(10, 'jami uy parrandalari soni', '2055 ta'),
(11, 'Quyonchilik bilan shug\'ullanadigan xonadonlar soni', '12 ta'),
(12, 'quyonlar soni', '48 bosh'),
(13, 'Asalarichilik bilan shug\'ullanadigan xonadonlar soni', '2 ta'),
(14, 'jami asalari oilalari (uyalar) soni', '75 ta');

-- --------------------------------------------------------

--
-- Структура таблицы `talim_muassasalari`
--

CREATE TABLE `talim_muassasalari` (
  `id` int(11) UNSIGNED NOT NULL,
  `muassasa_nomi` varchar(100) NOT NULL,
  `soni` int(255) NOT NULL,
  `oquvchilar` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `talim_muassasalari`
--

INSERT INTO `talim_muassasalari` (`id`, `muassasa_nomi`, `soni`, `oquvchilar`) VALUES
(1, 'Maktabgacha ta\'lim muassasalari', 5, 237),
(2, 'Maktablar', 1, 1056),
(3, 'Musiqa va San\'at maktablari', 0, 0),
(4, 'Bolalar va o\'smirlar sport maktablari', 0, 0),
(5, 'Ixtisoslashgan sport maktablari', 0, 0),
(6, 'Litseylar', 0, 0),
(7, 'Kollejlar soni', 0, 0),
(8, 'Texnikumlar soni', 0, 0),
(9, 'Oliy o\'quv yurtlari soni', 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `tashkilot_va_obektlar`
--

CREATE TABLE `tashkilot_va_obektlar` (
  `id` int(11) UNSIGNED NOT NULL,
  `korsatkichlar` varchar(100) NOT NULL,
  `birlik` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `tashkilot_va_obektlar`
--

INSERT INTO `tashkilot_va_obektlar` (`id`, `korsatkichlar`, `birlik`) VALUES
(1, 'Kutubxonalar soni', '1 ta'),
(2, 'Savdo do\'konlari soni', '48 ta'),
(3, 'To\'yxonalar soni', '2 ta'),
(4, 'Umumiy ovqatlanish shaxobchalari soni', '5 ta'),
(5, 'Dorixonalar soni', '25 ta'),
(6, 'Shifoxonalar soni', '1 ta'),
(7, 'Qabristonlar soni', '1 ta'),
(8, 'Mahalla hududida joylashgan vazirlik, idora, tashkilotlar, muassasalar va ularning quyi tuzilmalari ', '1 ta'),
(9, 'Bozorlar soni', 'Yo\'q'),
(10, 'O\'qitish va o\'rgatish markazlari soni', 'Yo\'q');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `aholining_bandligi`
--
ALTER TABLE `aholining_bandligi`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `aholining_ijtimoiy_holati`
--
ALTER TABLE `aholining_ijtimoiy_holati`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `data1`
--
ALTER TABLE `data1`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `data2`
--
ALTER TABLE `data2`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `demografik_korsatkichlar`
--
ALTER TABLE `demografik_korsatkichlar`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `qishloq_xojaligi`
--
ALTER TABLE `qishloq_xojaligi`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `talim_muassasalari`
--
ALTER TABLE `talim_muassasalari`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `tashkilot_va_obektlar`
--
ALTER TABLE `tashkilot_va_obektlar`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `aholining_bandligi`
--
ALTER TABLE `aholining_bandligi`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT для таблицы `aholining_ijtimoiy_holati`
--
ALTER TABLE `aholining_ijtimoiy_holati`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT для таблицы `data1`
--
ALTER TABLE `data1`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT для таблицы `data2`
--
ALTER TABLE `data2`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `demografik_korsatkichlar`
--
ALTER TABLE `demografik_korsatkichlar`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT для таблицы `qishloq_xojaligi`
--
ALTER TABLE `qishloq_xojaligi`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT для таблицы `talim_muassasalari`
--
ALTER TABLE `talim_muassasalari`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `tashkilot_va_obektlar`
--
ALTER TABLE `tashkilot_va_obektlar`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
