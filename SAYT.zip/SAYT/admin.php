<?php
 include "connect.php";
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <script src="js/bootstrap.min.js"></script>
    <title>Mahalla pasporti</title>

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
     <!-- Favicon -->
     <link href="img/favicon.ico" rel="icon">

<!-- Google Web Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&family=Rubik:wght@400;500;600;700&display=swap" rel="stylesheet">

<!-- Icon Font Stylesheet -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

<!-- Libraries Stylesheet -->
<link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
<link href="lib/animate/animate.min.css" rel="stylesheet">

<!-- Customized Bootstrap Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet">

<!-- Template Stylesheet -->
<link href="css/style.css" rel="stylesheet">

</head>
<body>
    
    <!-- Topbar Start -->
    <div class="container-fluid bg-dark px-5 d-none d-lg-block">
        <div class="row gx-0">
            <div class="col-lg-8 text-center text-lg-start mb-2 mb-lg-0">
                <div class="d-inline-flex align-items-center" style="height: 45px;">
                    <small class="me-3 text-light"><i class="bi bi-geo-alt text-primary me-2"></i>Yangiariq tumani Ogahiy mahallasi</small>
                    <small class="me-3 text-light"><i class="bi bi-clock text-primary me-2"></i> Dushshanba - Shanba : 08:30 dan - 17:30 gacha</small>
                </div>
            </div>
            <div class="col-lg-4 text-center text-lg-end">
                <div class="d-inline-flex align-items-center" style="height: 45px;">
                    <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href="https://twitter.com"><i class="fab fa-twitter fw-normal"></i></a>
                    <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href="https://facebook.com"><i class="fab fa-facebook-f fw-normal"></i></a>
                    <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href="https://linkedin.com"><i class="fab fa-linkedin-in fw-normal"></i></a>
                    <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href="https://instagram.com"><i class="fab fa-instagram fw-normal"></i></a>
                    <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle" href="https://youtube.com"><i class="fab fa-youtube fw-normal"></i></a>
                </div>
            </div>
        </div>
    </div>
    <!-- Topbar End -->

<!-- Navbar Start -->
<div class="container-fluid position-relative p-0">
        <nav class="navbar navbar-expand-lg navbar-dark px-5 py-3 py-lg-0">
            <a href="index.php" class="navbar-brand p-0">
                <h1 class="m-0"><i class="fa fa-users me-2"></i>Ogahiy MFY</h1>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="fa fa-bars"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav ms-auto py-0">
                    <a href="index.php" class="nav-item nav-link">Bosh sahifa</a>               
                    <div class="nav-item dropdown">
                        <a href="page.php" class="nav-link nav-link active">Mahalla pasporti</a>
                    </div>
                    <a href="contact.php" class="nav-item nav-link">Contact</a>
                </div>
            </div>
        </nav>

        <div class="container-fluid bg-primary py-5 bg-dark" style="margin-bottom: 90px;">
            <div class="row py-5">
                <div class="text-wrapper ml1 col-12 pt-lg-5 mt-lg-5 text-center" >
                    <h2  class="letter display-4 text-white animated zoomIn text-uppercase" >Ogahiy  mahalla fuqarolar yig'inining pasporti</h2>
                </div>            
            </div>
        </div>
    </div>
    <!-- Navbar End -->
           
    <div class="container"><br>
       <table class="table table-bordered">
            <h4 class="text-center">Mahalla fuqarolar yig'ini xodimlari va jamoatchilik tuzilmalari to'g'risida ma'lumot</h4>
        <thead class="thead btn-info">
        <tr>
            <th scope="col" class="text-center">Lavozimlar</th>
            <th scope="col" class="text-center">F.I.SH</th>
            <th scope="col" class="text-center">Yashash manzili</th>
            <th scope="col" class="col-sm-2 text-center">Telefon raqami</th>
        </tr>
        </thead>
        <tbody>
        <?php
        global $conn;
        $sql = "SELECT * FROM data1";
        $result = mysqli_query($conn,$sql);
        if($result){
            while ($row = mysqli_fetch_assoc($result)){
                $id = $row['id'];
                $lavozimlar = $row['lavozimlar'];
                $F_I_SH = $row['F_I_SH'];
                $yashash_manzili = $row['yashash_manzili'];
                $phone_number = $row['phone_number'];
                echo "<tr>
            <td>$lavozimlar</td>
            <td>$F_I_SH</td>
            <td>$yashash_manzili</td>
            <td class='text-center'>$phone_number</td>
        </tr>";
            }
        }
        ?>
        </tbody>
    </table><br>
    <table class="table table-bordered">
    <h4 class="text-center">Fuqarolar yig'inlari huzuridagi jamoatchilik tuzilmalari to'g'risida ma'lumot</h4>    
        <thead class="thead btn-info">
        <tr>
            <th scope="col" class="text-center">Lavozimlar</th>
            <th scope="col" class="text-center">F.I.SH</th>
            <th scope="col" class="text-center">Telefon raqami</th>
            <th scope="col" class="text-center">Azolar soni</th>
        </tr>
        </thead>
        <tbody>
        <?php
        global $conn;
        $sql = "SELECT * FROM data2";
        $result = mysqli_query($conn,$sql);
        if($result){
            while ($row = mysqli_fetch_assoc($result)){
                $id = $row['id'];
                $lavozimlar = $row['lavozimlar'];
                $F_I_SH = $row['F_I_SH'];
                $phone_number = $row['phone_number'];
                $azolar_soni = $row['azolar_soni'];
                echo "<tr>
            <td>$lavozimlar</td>
            <td>$F_I_SH</td>
            <td class='text-center'>$phone_number</td>
            <td class='text-center'>$azolar_soni</td>
        </tr>";
            }
        }
        ?>
        </tbody>
    </table><br>
    <table class="table table-bordered">
        <h4 class="text-center">Demografik ko'rsatkichlar</h4>
        <thead class="thead btn-info">
        <tr>
            <th class="col text-center" scope="col">Ko'rsatkichlar</th>
            <th class="col-sm-2 text-center" scope="col">Jami</th>
        </tr>
        </thead>
        <tbody>
        <?php
        global $conn;
        $sql = "SELECT * FROM demografik_korsatkichlar";
        $result = mysqli_query($conn,$sql);
        if($result){
            while ($row = mysqli_fetch_assoc($result)){
                $id = $row['id'];
                $korsatkichlar = $row['korsatkichlar'];
                $jami = $row['jami'];
                echo "<tr>
            <td>$korsatkichlar</td>
            <td class='text-center'>$jami</td>
        </tr>";
            }
        }
        ?>
        </tbody>
    </table><br>
    <table class="table table-bordered">
        <h4 class="text-center">Aholining bandligi</h4>
        <thead class="thead btn-info">
        <tr>
            <th scope="col" class="text-center">Ko'rsatkichlar</th>
            <th scope="col" class="text-center">Kishi</th>
        </tr>
        </thead>
        <tbody>
        <?php
        global $conn;
        $sql = "SELECT * FROM aholining_bandligi";
        $result = mysqli_query($conn,$sql);
        if($result){
            while ($row = mysqli_fetch_assoc($result)){
                $id = $row['id'];
                $korsatkichlar = $row['korsatkichlar'];
                $kishi = $row['kishi'];
                echo "<tr>
            <td>$korsatkichlar</td>
            <td class='text-center'>$kishi</td>
        </tr>";
            }
        }
        ?>
        </tbody>
    </table><br>
    <table class="table table-bordered">
        <h4 class="text-center">Aholining ijtimoiy holati</h4>
        <thead class="thead btn-info">
        <tr>
            <th scope="col" class="text-center">Ko'rsatkichlar</th>
            <th scope="col" class="text-center">Kishi</th>
        </tr>
        </thead>
        <tbody>
        <?php
        global $conn;
        $sql = "SELECT * FROM aholining_ijtimoiy_holati";
        $result = mysqli_query($conn,$sql);
        if($result){
            while ($row = mysqli_fetch_assoc($result)){
                $id = $row['id'];
                $korsatkichlar = $row['korsatkichlar'];
                $kishi = $row['kishi'];
                echo "<tr>
            <td>$korsatkichlar</td>
            <td class='text-center'>$kishi</td>
        </tr>";
            }
        }
        ?>
        </tbody>
    </table><br>
    <table class="table table-bordered">
        <h4 class="text-center">Hududdagi tashkilot va ob'ektlar soni to'g'risida na'lumot</h4>
        <thead class="thead btn-info">
        <tr>
            <th scope="col" class="text-center">Ko'rsatkichlar</th>
            <th scope="col" class="text-center">Birlik</th>
        </tr>
        </thead>
        <tbody>
        <?php
        global $conn;
        $sql = "SELECT * FROM tashkilot_va_obektlar";
        $result = mysqli_query($conn,$sql);
        if($result){
            while ($row = mysqli_fetch_assoc($result)){
                $id = $row['id'];
                $korsatkichlar = $row['korsatkichlar'];
                $birlik = $row['birlik'];
                echo "<tr>
            <td>$korsatkichlar</td>
            <td class='text-center'>$birlik</td>
        </tr>";
            }
        }
        ?>
        </tbody>
    </table><br>
    <table class="table table-bordered">
        <h4 class="text-center">Qishloq xo'jaligi bilan bog'liq ko'rsatkichlar</h4>
        <thead class="thead btn-info">
        <tr>
            <th scope="col" class="text-center">Ko'rsatkichlar</th>
            <th scope="col" class="text-center">Birlik</th>
        </tr>
        </thead>
        <tbody>
        <?php
        global $conn;
        $sql = "SELECT * FROM qishloq_xojaligi";
        $result = mysqli_query($conn,$sql);
        if($result){
            while ($row = mysqli_fetch_assoc($result)){
                $id = $row['id'];
                $korsatkichlar = $row['korsatkichlar'];
                $birlik = $row['birlik'];
                echo "<tr>
            <td>$korsatkichlar</td>
            <td class='text-center'>$birlik</td>
        </tr>";
            }
        }
        ?>
        </tbody>
    </table><br>
    <table class="table table-bordered">
        <h4 class="text-center">Ta'lim muassasalari to'g'risida</h4>
        <thead class="thead btn-info">
        <tr>
            <th scope="col" class="text-center">Muassasa nomi</th>
            <th scope="col" class="text-center">Soni</th>
            <th scope="col" class="text-center">O'quvchilar</th>
        </tr>
        </thead>
        <tbody>
        <?php
        global $conn;
        $sql = "SELECT * FROM talim_muassasalari";
        $result = mysqli_query($conn,$sql);
        if($result){
            while ($row = mysqli_fetch_assoc($result)){
                $id = $row['id'];
                $muassasa_nomi = $row['muassasa_nomi'];
                $soni = $row['soni'];
                $oquvchilar = $row['oquvchilar'];
                echo "<tr>
            <td>$muassasa_nomi</td>
            <td class='text-center'>$soni</td>
            <td class='text-center'>$oquvchilar</td>
        </tr>";
            }
        }
        ?>
        </tbody>
    </table>
    </div> 

    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-light mt-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container">
            <div class="row gx-5">
                <div class="col-lg-8 col-md-6">
                    <div class="row gx-5">
                        <div class="col-lg-4 col-md-12 pt-5 mb-5">
                            <div class="section-title section-title-sm position-relative pb-3 mb-4">
                                <h3 class="text-light mb-0">Bog'lanish</h3>
                            </div>
                            <div class="d-flex mb-2">
                                <i class="bi bi-geo-alt text-primary me-2"></i>
                                <p class="mb-0">Yangiariq tumani, Ogahiy MFY</p>
                            </div>
                            <div class="d-flex mb-2">
                                <i class="bi bi-envelope-open text-primary me-2"></i>
                                <p class="mb-0">ogahiymfy@gmail.com</p>
                            </div>
                            <div class="d-flex mb-2">
                                <i class="bi bi-telephone text-primary me-2"></i>
                                <p class="mb-0">+998 99 111 22 33</p>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-12 pt-0 pt-lg-5 mb-5">
                            <div class="section-title section-title-sm position-relative pb-3 mb-4">
                                <h3 class="text-light mb-0">Tez havolalar</h3>
                            </div>
                            <div class="link-animated d-flex flex-column justify-content-start">
                                <a class="text-light mb-2" href="index.php"><i class="bi bi-arrow-right text-primary me-2"></i>Bosh sahifa</a>
                                <a class="text-light" href="contact.php"><i class="bi bi-arrow-right text-primary me-2"></i>Biz bilan bog'lanish</a>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-12 pt-0 pt-lg-5 mb-5">
                            <div class="section-title section-title-sm position-relative pb-3 mb-4">
                                <h3 class="text-light mb-0">Ommabop havolalar</h3>
                            </div>
                            <div class="link-animated d-flex flex-column justify-content-start">
                                <a class="text-light mb-2" href="index.php"><i class="bi bi-arrow-right text-primary me-2"></i>Bosh sahifa</a>
                                <a class="text-light" href="contact.php"><i class="bi bi-arrow-right text-primary me-2"></i>Biz bilan bog'lanish</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->

    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square rounded back-to-top"><i class="bi bi-arrow-up"></i></a>


<!-- JavaScript Libraries -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="lib/wow/wow.min.js"></script>
<script src="lib/easing/easing.min.js"></script>
<script src="lib/waypoints/waypoints.min.js"></script>
<script src="lib/counterup/counterup.min.js"></script>
<script src="lib/owlcarousel/owl.carousel.min.js"></script>

<!-- Template Javascript -->
<script src="js/main.js"></script>
    </body>
    </html>